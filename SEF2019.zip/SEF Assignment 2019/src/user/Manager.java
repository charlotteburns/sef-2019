package user;
import java.util.List;

public class Manager extends Employee{

	public Manager(String id, String name, String address, String phoneNo) {
		super(id, name, address, phoneNo);		
	}
}
