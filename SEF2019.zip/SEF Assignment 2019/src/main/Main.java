package main;

import model.SupermarketSystem;

public class Main {

	public static void main(String[] args){
		SupermarketSystem supermarket = new SupermarketSystem();
		supermarket.run();
	}
}
