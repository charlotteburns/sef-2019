package warehouse;

import java.util.*;
public class Supplier {

	private String id;
	private String name;

	//private Map<String double>products;

	public Supplier(String id, String name) {
		this.id = id;
		this.name = name;
	}

	public String getId() {

		return id;
	}

	public String getName() {

		return name;
	}

}
